package com.example.myfirstapplication

class RecyclerView(
    private val listaUsuario: List<UsuarioHttp>,
    private val recyclerView: RecyclerView
) {
}